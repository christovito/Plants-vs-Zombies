public interface Shooter {
    public long SHOOT_DELAY = 2000;
    public void shoot(GameBoard gameBoard);
}