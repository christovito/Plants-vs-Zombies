public class BulletPea extends Bullet{
    
    public BulletPea(int row, int col){
        super(row, col);
        this.damage = 10;
    }
}