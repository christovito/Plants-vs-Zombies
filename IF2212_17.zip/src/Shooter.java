public interface Shooter {
    public void shoot(Backyard backyard, Game game);
} 