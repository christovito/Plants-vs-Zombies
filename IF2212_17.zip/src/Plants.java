public class Plants extends BackyardMaterials {

    public Plants(int row, int col){
        super(row, col);
        this.speed = 0;
    }

    public void shoot(Backyard backyard, Game game){
    }

    public void produceSun(Backyard backyard, Game game){
    }
}