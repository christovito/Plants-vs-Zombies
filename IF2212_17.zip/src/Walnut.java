public class Walnut extends Plants{

    public Walnut(int row, int col){
        super(row, col);
        this.symbol = "W";
        this.health = 150;
        this.cost = 50;
        this.damage = 0;
    }   
}