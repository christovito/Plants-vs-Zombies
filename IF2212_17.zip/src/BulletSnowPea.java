public class BulletSnowPea extends Bullet{
    
    public BulletSnowPea(int row, int col){
        super(row, col);
        this.damage = 20;
    }
}